﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyUserControl : System.Web.UI.UserControl
{

    private int idProcess = -1;

    public int IdProcess
    {
        get { return idProcess; }
        set { idProcess = value; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        SqlDataSource sds = new SqlDataSource();
        sds.ProviderName = ConfigurationManager.ConnectionStrings["MainDbSource"].ProviderName;
        sds.ConnectionString = ConfigurationManager.ConnectionStrings["MainDbSource"].ConnectionString;
        sds.SelectCommand = "SELECT [ID_PROCESS_INST], CAST([ID_PROCESS_INST] AS NVARCHAR) +' - '+ [DESCRIPTION] AS COL2 FROM [WFPROCESS_INST] " + (idProcess>0? " WHERE ID_PROCESS=" + IdProcess : String.Empty);

        this.REQUESTS.DataSource = sds;
        this.REQUESTS.DataTextField = "COL2";
        this.REQUESTS.DataValueField = "ID_PROCESS_INST";
        this.REQUESTS.DataBind();
        
    }

    protected void CopyData(object sender, System.EventArgs e)
    {
    }

}
